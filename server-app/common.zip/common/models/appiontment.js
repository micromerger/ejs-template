'use strict';

module.exports = function(Appiontment) {

};

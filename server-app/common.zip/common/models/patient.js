'use strict';

module.exports = function(Patient) {

};

'use strict';

module.exports = function(Order1) {

};

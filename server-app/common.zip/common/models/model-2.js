'use strict';

module.exports = function(Model2) {

};

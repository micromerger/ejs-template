'use strict';

module.exports = function(Doctor) {

};
